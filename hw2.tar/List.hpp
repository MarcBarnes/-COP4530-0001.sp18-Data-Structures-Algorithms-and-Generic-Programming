//Marcus Barnes
//List.hpp
using namespace std;

//give the form of complexity in big 0 format and
//give an explaination for example for loop runs n times
//then 0(n) is the complexity of my reverse;

/****************************************************
//		TEMPLATE T GLOBAL functions
//		DEFINITIONS 
//
/****************************************************/
template <typename T>
bool operator!=(const List<T> & lhs, const List<T> &rhs)
{ 
 		//I am creating some easy to use iterators L and R
    	typename List<T>::const_iterator::const_iterator L = lhs.begin();
    	typename List<T>::const_iterator::const_iterator R = rhs.begin();		
    	
    	//while loop to increment iterators throuch each list
    	while(L != lhs.end())
    	{
			if(*L != *R)		//if we run across one inequallity we return true
				return true; 

			L++;	//incrementing both iterators
			R++;
		}

		//checking, if rhs isn't at the end. if it isnt, it means that the 2 lists 
		//have different lengths thus unequal, return true
		if(R != rhs.end())
			return true;

		return false;	//returns false if we met no inaccuracies
}
//must have to iterator it
//can check the pointer or check the data
// overloading output operator in the template T
template <typename T>
bool operator==(const List<T> & lhs, const List<T> &rhs)
{ 
	
		//I am creating some easy to use iterators L and R
    	typename List<T>::const_iterator::const_iterator L = lhs.begin();
    	typename List<T>::const_iterator::const_iterator R = rhs.begin();		
    	
    	//while loop to increment iterators throuch each list
    	while(L != lhs.end())
    	{
			if(*L != *R)
				return false; 

			L++;	//incrementing both iterators
			R++;
		}

		//must add in another conditions to check that 
		//there aren't any extra elements in rhs list
		if(R != rhs.end())
			return false;

		return true;	//returns true if we met nothing false
		
	
}
// overloading output operator in the template T
template <typename T>
std::ostream & 
 operator<<(std::ostream &os, const List<T> &l)
{ 		
	l.print( os ); 	//calls the print function, passing in the ostream &os
	return os;			
}

/****************************************************
//		CONST_ITERATOR member functions
//		DEFINITIONS (nested)
//
/****************************************************/
template <typename T>
List<T>::const_iterator::const_iterator() : current{ nullptr } // default zero parameter constructor
{}

template <typename T>
List<T>::const_iterator::const_iterator(Node *p) : current{ p } // protected constructor
{ }

template <typename T>
const T & 
List<T>::const_iterator::operator*() const // operator*() to return element
{ return retrieve( ); 
}

template <typename T>
typename List<T>::const_iterator &	//prefix increment
List<T>::const_iterator::operator++()
{ 	
	current = current->next;
  	return *this;
}

template <typename T>
typename List<T>::const_iterator 	//postfix increment
List<T>::const_iterator::operator++(int)
{ 	
 	const_iterator old = *this;
 	++( *this );
 	return old;
}

template <typename T>
typename List<T>::const_iterator &
List<T>::const_iterator::operator--()
{ 	
	current = current->prev;
   	return *this;
}

template <typename T>
typename List<T>::const_iterator 
List<T>::const_iterator::operator--(int)
{ 	
	const_iterator old = *this;
    --( *this );
    return old;
}

template <typename T>					//checks if the iterators point to same spot
bool List<T>::const_iterator::operator== ( const const_iterator &rhs) const
{ return current == rhs.current; }

template <typename T>					//checks if equal
bool List<T>::const_iterator::operator!= ( const const_iterator &rhs) const
{ return !( *this == rhs ); }


/****************************************************
//		ITERATOR member functions
//		DEFINITIONS (nested)
//
/****************************************************/
template <typename T>
List<T>::iterator::iterator() // default zero parameter constructor
{}

template <typename T>
 List<T>::iterator::iterator(Node *p) : const_iterator{ p } // protected constructor
{ }

template <typename T>
T & 
List<T>::iterator::operator*()					//return a ref to the corresponding 
{ return List<T>::const_iterator::retrieve( ); }//element in the list

template <typename T>
typename List<T>::iterator &	//prefix increment
List<T>::iterator::operator++()
{ 	
	this->current = this->current->next;
    return *this;
}

template <typename T>
typename List<T>::iterator 	//postfix increment
List<T>::iterator::operator++(int)
{ 	
 	iterator old = *this;
    ++( *this );
    return old;
}

template <typename T>
typename List<T>::iterator &

List<T>::iterator::operator--()
{ 	
	this->current = this->current->prev;
	return *this;

}

template <typename T>
typename List<T>::iterator 
List<T>::iterator::operator--(int)
{ 	
	iterator old = *this;
	--( *this );
    return old;

}

/****************************************************
//		LIST member functions
//		DEFINITIONS
//
/****************************************************/
template <typename T>
List<T>::List()				//default zero parameter constructor
{init();}

template <typename T>		//copy constructor 
List<T>::List(const List & rhs)
{
	init( );
	for(auto & x :rhs )
		push_back(x);
}

template <typename T>		//move constructor
List<T>::List(List && rhs)
 : theSize{ rhs.theSize }, head{ rhs.head }, tail{ rhs.tail }
{
  rhs.theSize = 0;
  rhs.head = nullptr;
  rhs.tail = nullptr;
}

//constructing a List with elements from another list between start and end. 
//Including the element referred to by the start iterator, but not the end itr
//, that is [start,end)
template <typename T>
List<T>::List(const_iterator start, const_iterator end)
{
	init();
	
	while(start != end)
	{
        push_back(*start);
        start++;
    }
    
}
							//construct a list with num elements, all initialized
							// with value val
template <typename T>		//num elements with value of val
List<T>::List(int num, const T & val )
{
	init();
	for (int i = 0; i < num; i++)
	push_front(val);
	theSize = num;
}


template <typename T>
typename List<T>::iterator 
List<T>::insert(iterator itr, const T & val) // insert val ahead of itr
{
	Node *p = itr.current;
    theSize++;
	return iterator( p->prev = p->prev->next = new Node( val, p->prev, p ) );
}

template <typename T>
typename List<T>::iterator 
List<T>::insert(iterator itr, T && val) // move version of insert
{
	Node *p = itr.current;
    ++theSize;
    return iterator( p->prev = p->prev->next = new Node{ move( val ), p->prev, p } );

}

template <typename T>
List<T>::~List()			 // destructor
{
	clear();
	delete head;
	delete tail;
}

template <typename T>
void List<T>::init( )			//init() definition
{
	theSize = 0;
	head = new Node;
	tail = new Node;
	head->next = tail;
	tail->prev = head;
}

template <typename T>
T &
List<T>::front() // reference to the first element
{ return *begin( );  }

template <typename T>
T &
List<T>::back() // reference to the last element
{ return *--end( );  }



template <typename T>
typename List<T>::List & 			// move assignment operator
List<T>::operator=(List && rhs)
{    
    std::swap( theSize, rhs.theSize );
    std::swap( head, rhs.head );
    std::swap( tail, rhs.tail );
    return *this;
}

template <typename T>	
const typename List<T>::List&		// copy assignment operator
List<T>::operator=(const List &rhs)
{ 
	List copy = rhs;
    std::swap( *this, copy );
    return *this;
}

template <typename T>				// remove all elements from with value = val
void List<T>::remove(const T &val) 	//from the calling object
{ 
	List<T>::iterator I = this->begin();
	while( I != this->end())
	{
		if (val == *I)
			I = this->erase(I);
		else
			I++;
	}
}



template <typename T>
void List<T>::push_front(const T & val) 	// insert to the beginning
{ insert(begin(),val); }

template <typename T>
void List<T>::push_front(T && val) 			// move version of insert
{ insert( begin( ), std::move( val ) );  }

template <typename T>
void List<T>::push_back(const T & val) 		// insert to the end
{  insert( end( ), val ); }

template <typename T>
void List<T>::push_back(T && val) 			// move version of insert
{ insert( end( ), std::move( val ) );  }  

template <typename T>
void List<T>::pop_front() 					// delete first element
{ erase( begin( ) );  }

template <typename T>
void List<T>::pop_back() 					// delete last element
{ erase( --end( ) );  }

template <typename T>
typename List<T>::iterator 
List<T>::begin() // iterator to first element
{ return iterator( head->next );  }


template <typename T>
typename List<T>::iterator 
List<T>::end() // end marker iterator
{ return iterator( tail );  }

template <typename T>
typename List<T>::const_iterator 			//return first iterator
List<T>::begin() const
{ return const_iterator( head->next );  }

template <typename T>
typename List<T>::const_iterator 			//access end
List<T>::end() const
{  return const_iterator( tail );  }

template <typename T>
typename List<T>::iterator 
List<T>::erase(iterator itr) // erase one element
{
    Node *p = itr.current;
    iterator retVal( p->next );
    p->prev->next = p->next;
    p->next->prev = p->prev;
    delete p;
    --theSize;
    return retVal;

}

template <typename T>
typename List<T>::iterator 
List<T>::erase(iterator start, iterator end) // erase [start, end)
{
	for( iterator itr = start; itr != end; )
        itr = erase( itr );
    return end;
}

template <typename T>				//empty function
bool List<T>::empty( ) const
{ return size( ) == 0; }

template <typename T>				//size function, return theSize
int List<T>::size( ) const
{ return theSize; }

template <typename T>				//clear all elements
void List<T>::clear( )
{
	while( !empty( ) )
	pop_front( );
}


//I NEED HELP WITH THE FOLLOWING DEFINITIONS





//within the List scope resolution
template <typename T>
void List<T>::print(ostream& os, char ofc) const
{ 
	List<T>::const_iterator I = this->begin();
	while( I != this->end())
	{
			cout<< I.retrieve()<< ofc;
			I++;
	}
} 
template <typename T>
T & List<T>::const_iterator::retrieve() const // retrieve the element refers to
{ return current->data;  }

//within the List scope resolution
template <typename T>
void List<T>::reverse() // reverse the order of the elements
{

	List<T> temp ;	//I am creating some easy to use iterators B and E of calling object
	//List<T>::temp.print();
	//temp.init();
    typename List<T>::const_iterator::const_iterator B = begin();
    typename List<T>::const_iterator::const_iterator E = end();		
   // E--;

    cout<<"\nbegin: "<< *begin()<<" End: "<<*(--end())<<endl;
    
	//temp.push_back(*E);
	//E++;
	//temp.push_back(*E);

	cout<<"mytemp: "<< temp<<endl;

/*
    theSize = 0;
	head = new Node;
	tail = new Node;
	head->next = tail;
	tail->prev = head;
	*/
    //while loop to increment iterators throuch each list
    /*
    while(E != B)
    {
    		List<T>::temp.push_back(*E);
    	cout<<"call "<<*E<<" ";	
		--E;	
	}
	
	cout<< "my temp: "<<temp<<" ";	

	E = end();
	*/
	
	//typename List<T>::const_iterator::const_iterator I = temp.begin();
    // typename List<T>::const_iterator::const_iterator Iend = temp.end();
     int count = 0;

    // List<T>::operator=(&temp);
     //this->operator=( &temp);
     /*
	for(I; I> Iend; I++)
	{

		this.operator=( &temp);
		cout<<"tempptr: "<< *I<< " ";
		count++;
		B++;
	}	
     //clear();
     */
/*
	while(I != IE)
    {
    	this->push_back(*I);
		cout<<"call "<<*I<<" ";	
		--I;	
	}

*/	
	
	cout<<"Inside of the reverse function: ";
	

	/*
	List<T>::iterator x = begin();
	List<T>::iterator y = --end();


	while ((x!=y)&&(x!=--y)) 
	{
    	std::swap (x,y);
    	++x;
 	}
 	*/

}

