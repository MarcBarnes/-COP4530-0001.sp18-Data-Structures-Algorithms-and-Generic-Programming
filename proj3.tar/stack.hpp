using namespace std;

//zero arg constructor
template <typename T>
Stack<T>::Stack()
{
	//vector<T> myVector;
}

//destructor
template <typename T>
Stack<T>::~Stack ()
{
	//delete [] myVector;	
	myVector.erase(myVector.begin(),myVector.end()); 
}

//copy constructor
template <typename T>
Stack<T>::Stack(const Stack<T>& rhv)
{ myVector = rhv.myVector; }

//move constuctor
template <typename T>
Stack<T>::Stack(Stack<T>&& rhs)
	:myVector {rhs.myVector}
{ vector<T>().swap(rhs); }

//copy assignment operator=
template <typename T>
Stack<T>&
Stack<T>::operator= (const Stack <T>& rhs)
{myVector = rhs.myVector;}

//move assignment operator=
template <typename T>
Stack<T> & 
Stack<T>::operator= (Stack<T>&& rhs )
{
	std::swap(myVector, rhs.myVector);
	return *this;
}

//checks if Stack contains no elments, returns true if empty false otherwise
template <typename T>
bool Stack<T>::empty() const
{
	if (myVector.empty())
		return true;
	else
		return false;
}

//delete all elements from the stack
template <typename T>
void Stack<T>::clear()
{ myVector.erase(myVector.begin(),myVector.end()); }


//adds x to the Stack. copy version
template <typename T>
void Stack<T>::push(const T& x)
{
	myVector.push_back(x);
}

//adds x to the Stack . mover version
template <typename T>
void Stack<T>::push(T && x)
{ myVector.push_back(std::move(x)); }

//removes and discards the most recently added element of the Stack
template <typename T>
void Stack<T>::pop()
{

	myVector.pop_back(); 
}

//mutator that returns a reference to the most recently added element of the Stack
template <typename T>
T& Stack<T>::top()
{  

	return myVector.back(); 
}

//accessor that returns the most recently added element of the Stack
template <typename T>
const T& Stack<T>::top() const
{
	return myVector.back();
}

//returns the number of elements stored in the Stack
template <typename T>
int Stack<T>::size() const
{ return myVector.size(); }

//print elements of Stack to ostream os. ofc is the separator between elements 
//in the stack when they are printed out. 
//Note that: print() prints elements in the opposite order of the Stack (that is, 
//the oldest element should be printed first)
template <typename T>
void Stack<T>::print(std::ostream& os, char ofc ) const
{
	for (unsigned int i = 0; i < myVector.size(); i++)
		os<< myVector[i] << ofc;
}

/*-------------------------------------------
	GLOBAL FUNCTIONS
-------------------------------------------*/
template <typename T>
std::ostream & 
operator<<(std::ostream& os, const Stack<T>& a)
{ 
	a.Stack<T>::print( os );
	return os;
}

//returns true if the two compared Stacks hav the same elements, in the same order
template <typename T>
bool operator== (const Stack<T>& lhs, const Stack <T>& rhs)
{
	//std::cout<<lhs.size();
	//std::cout<<lhs.size();
	if (lhs.size() != rhs.size())	// preventing work if size is different ,then unequal
		return false;

	//auto itr = rhs.begin();
	//std::cout<< *itr;
	//auto && litr = lhs;
	//auto && ritr = rhs;
	//std::cout<<litr.size();
	//std::cout<<ritr.size();
	//Stack<T> * p = lhs.data();
	Stack<T> templhs = lhs;
	Stack<T> temprhs = rhs;
	while (!(templhs.empty()))
	{
		if (templhs.top() != temprhs.top())
			return false;					//found unequality
		templhs.pop();
		temprhs.pop();
	}

	return true;
}

//opposite of operator==()
template <typename T>
bool operator!= (const Stack<T>& lhs, const Stack<T>& rhs)
{
	if (lhs.size() != rhs.size())	// preventing work if size is different ,then unequal
		return true;

	Stack<T> templhs = lhs;
	Stack<T> temprhs = rhs;

while (!(templhs.empty()))
	{
		if (templhs.top() != temprhs.top())
			return true;					//found unequality
		templhs.pop();
		temprhs.pop();
	}

	return false;	//stacks are equal


}

//returns true if every element in Stack a is smaller than or equal to the 
//corresponding element of Stack b, i.e., if repeatedly invoking top() and
//pop() on both a and b, we will generate a sequence of elements a_i from a and 
//b_i from b, and for every i, a_i <= b_i, until a is empty
template <typename T>
bool operator<= (const Stack<T>& a, const Stack <T>& b)
{

	if (a.size() != b.size())	// preventing work if size is different ,then unequal
		return false;

	Stack<T> templhs = a;
	Stack<T> temprhs = b;

	while (!(templhs.empty()))
	{
		if (templhs.top() > temprhs.top())
			return false;					//found unequality
		templhs.pop();
		temprhs.pop();
	}

	return true;	//stacks a is less than or equal to b



}