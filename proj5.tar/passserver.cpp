//Marcus Barnes
//passserver.cpp
//cop4530
//proj5
#include "passserver.h"

PassServer::PassServer(size_t size )
{ 
	atable = new cop4530::HashTable < std::string, std::string> (size);	//atable as an adaptor to the hashtable, calling its constructor
	atablesize = 0;
	password = 0;
}
  
PassServer::~PassServer()
{ 
	if (password != 0)
		delete password;
	delete atable;
}

bool PassServer::load(const char *filename)
{ return atable->load(filename); }

bool PassServer::addUser(std::pair<std::string,  std::string> & kv)
{ 
	if (atable->contains (kv.first)) 
		return false;
	++atablesize;
	return (atable->insert(make_pair(kv.first, encrypt(kv.second))));
}

bool PassServer::addUser(std::pair<std::string, std::string> && kv)
{ 
	if (atable->contains(kv.first))
		return false;

	return atable->insert(make_pair(std::move(kv.first), encrypt(std::move(kv.second))));
	++atablesize;

}

bool PassServer::removeUser(const std::string & k)
{
	return atable->remove(k);
	--atablesize; 
}

bool PassServer::changePassword(const std::pair<std::string, std::string> &p, const std::string & newpassword)
{ 

	if (atable->match( make_pair(p.first, encrypt(p.second))))	//matched un and encrypted pw 
	{
		if (encrypt(newpassword) == encrypt(p.second))	//if user tries to make new pw same as old
			return false;

		atable->insert(make_pair(p.first, encrypt(newpassword)));
		return true;
	}
	return false;
}

bool PassServer::find(const std::string & user)
{ return atable->contains(user); }

void PassServer::dump()
{ atable->dump(); }

size_t PassServer::size()
{ return atable->size(); }

bool PassServer::write_to_file(const char *filename)
{ return (atable->write_to_file(filename)); }

//: encrypt the parameter str and return the encrypted string.
std::string PassServer::encrypt(const std::string & str)
{
	if (password !=0)
		delete password;

	char salt[] = "$1$########";
	password = new char[40];
	std::string k = str;

	strcpy(password, crypt(k.c_str(), salt));
	std::string result(password);

	return result;
}