//Marcus Barnes
//proj5.cpp
//driver

#include <iostream>
#include <string>
#include <cctype>
#include <utility>
#include "passserver.h"
#include "hashtable.h"

using namespace std;
void Menu();


int main() {
  char choice;
  
  size_t capacity;
  string username, password, newpassword, loadfilename;

  cout<<"Enter the preferred hash table capacity: ";
  cin>> capacity;

  //cop4530::HashTable::HashTable hashtable = new cop4530::HashTable::<std::string, std::string>(capacity);

  PassServer server(capacity);
  //do/while loop until user enters x
  do{
    Menu();     //displays provided menu
    cin>>choice;  //collects user input

    if(choice=='l' ||choice=='a' ||choice=='r' ||choice=='c' ||choice=='f' ||choice=='d' ||choice=='s' ||choice=='w')
    {
      switch (choice)
      {
        case 'l'://Load From File
                  {
                    cout<< "Enter password file name to load from: ";
                    cin>>loadfilename;
                    if (server.load(loadfilename.c_str()))
                      break;
                    else
                      cout<< "Error: cannot open file: "<<loadfilename<<endl;
                    break;
                   } 
                
        case 'a'://Add User
                  {
                    
                    cout<<"Enter username: ";
                    cin>>username;
                    cout<<"Enter password: ";
                    cin>>password;

                    if(server.addUser(make_pair(username, password)))
                      cout<<"User "<< username<<" added.\n";
                    else
                      cout<<"*****Error: User already existys. Could not add user.\n";
                    break;
                  }
        case 'r'://Remove user
                  {
                    cout << "Enter username: ";
                    cin >> username;
                    if(server.removeUser(username))
                      cout << "User " << username << " deleted.";
                    else
                      cout << "ERROR: User not found.  Could not remove user.";
                    break;
                  }
        case 'c'://Change User Password
                  {
                    cout << "Enter username: ";
                    cin >> username;
                    cout << "Enter password: ";
                    cin >> password;
                    cout << "\nEnter new password: ";
                    cin >> newpassword;
                    if (server.changePassword(make_pair(username, password), newpassword))
                      {cout << "\nPassword changed for user " << username; break;}
                    cout << "Error: Could not change user password";
                    break;
                  }
        case 'f'://Find User
                  {
                    cout << "Enter username: ";
                    cin >> username;
                    if (server.find(username))
                      {cout << "\nUser '" << username << "' found."; break;}
                    cout << "\nUser '" << username << "' not found.";
                    break;                    
                  }
        case 'd'://Dump HashTable
                  {
                    server.dump();
                    break;
                  }
        case 's'://HashTable Size
                  {
                    cout << "Size of hashtable: " << server.size();
                    break;
                  }
        case 'w'://Write to Password File
                  {
                    cout << "Enter password file name to write to: ";
                    cin >> loadfilename; //not really loadfilename just used as temp variable
                    server.write_to_file(loadfilename.c_str());
                    break;
                  }                                   
      }//end switch
    }//end ifchoices
    else if(choice != 'x')
      cout<< "Incorrect choice. Please try again \n";


  }while (choice != 'x');
 

return 0;
}




void Menu()
{
  cout << "\n\n";
  cout << "l - Load From File" << endl;
  cout << "a - Add User" << endl;
  cout << "r - Remove User" << endl;
  cout << "c - Change User Password" << endl;
  cout << "f - Find User" << endl;
  cout << "d - Dump HashTable" << endl;
  cout << "s - HashTable Size" << endl;
  cout << "w - Write to Password File" << endl;
  cout << "x - Exit program" << endl;
  cout << "\nEnter choice : ";
}
