//MARCUS BARNES
//cop4530
//BINARY EXPRESSION TREE

#include <sstream>
#include <cctype>
#include <stack>
#include <vector>


//First, you need to build a binary expression tree from the postfix expression.

BET::BET()				// default zero-parameter constructor.
:root{nullptr}
{
nullNode = new BinaryNode;
nullNode->left = nullNode->right = nullNode; 
root = nullNode;
}
//one-parameter constructor, where parameter "postfix" is string containing a postfix expression. 
//The tree should be built based on the postfix expression. 
//Tokens in the postfix expression are separated by space.
//if tree contains nodes before passing postfix to function you need to first delete 
//the existing nodes
BET::BET(const string postfix)
:root{nullptr}	
{
	//cout<<"inside BT one param";
	nullNode = new BinaryNode;
	nullNode->left = nullNode->right = nullNode;
	root = nullNode; 
	buildFromPostfix(postfix);
}

BET::BET(const BET& rh) //: copy constructor.
:root{nullptr}
{ root = clone(rh.root); }	//this new root is a copy of the root at the given rh side

BET::~BET() //: destructor.
{ makeEmpty(root); }

//: parameter "postfix" is string containing a postfix expression. 
//The tree should be built based on the postfix expression. 
//Tokens in the postfix expression are separated by space. 
//If the tree contains nodes before the function is called, you need to first
// delete the existing nodes. Return true if the new tree is built successfully. 
//Return false if an error is encountered.

bool BET::buildFromPostfix(const string postfix) 
{
	stack <BET::BinaryNode*> stk;			//Stack to hold tolkens
	istringstream inputstream(postfix);	//input stream reading input
	vector <string> inputVect;			//vector to hold seperated tolkens of input

	string inputString;
	int numOfOperators = 0;				//keep number of operator
	int numOfOperands =0;				//keep track of num of Operands

	while (inputstream >> inputString)		//used to bring in input
	{
		inputVect.push_back(inputString);
		if(isalnum(inputString[0]))		//must decide if it is number or a vaiable
			++numOfOperands;						//if it is then it must be an operand
		else
			++numOfOperators;
	}

	//Return false if an error is encoutered
	//case1: we have corresponding operators to operand
	//case2; an operand does not have the corresponding operator
	//an expresssion with single operand is a valid expression is valid
	//....
	if (numOfOperands == 1 && numOfOperators == 0)
		{ }
	else if 
	(
		(numOfOperators != (numOfOperands - 1))||  //corresponding
		(			
			(isalnum(inputVect[inputVect.size() - 1][0])) || //only one tolken but not alphanumeric
			((inputVect.size() > 1) && ((!isalnum(inputVect[0][0]))))//first is not a alpanumeric
		)
	)//end of if conditional statemnt
	{
		cout<<"Error. incorrect format\n";
		return false;
	}

	//deciding what to do with each tolken
	for(unsigned int i = 0; i < inputVect.size(); ++i)	//runs through each tolken individually
	{
		BinaryNode *temp = new BinaryNode(); 
		temp->element = inputVect[i];		//pushing the iterated tolken onto our temp element
		
		if(isalnum(temp->element[0]))
			stk.push(temp);
		else
		{
			temp->right = stk.top();
			stk.pop();

			temp->left = stk.top();
			stk.pop();

			stk.push(temp);
		}



	}//end of for loop looking at each tolken of input individually
	root= stk.top();
	//cout<<"root; "<< root->element<<endl;
	return true;
}

const typename BET::BET & BET::operator= (const BET & rh) //: assignment operator.
{
	root = rh.clone(rh.root);
	return *this;
}

void BET::printInfixExpression() //: call the private version of the printInfixExpression function to print out the infix expression.
{ return printInfixExpression(root); }

void BET::printPostfixExpression() //: call the private version of the printPostfixExpression function to print out the postfix expression.
{  return printPostfixExpression(root); }

size_t BET::size() //: call the  private version of the size function to return the number of nodes in the tree.
{ return size(root); }

size_t BET::leaf_nodes() // : call the private version of the leaf_nodes function to return the number of leaf nodes in the tree.
{ return leaf_nodes(root); }

bool BET::empty() //: return true if the tree is empty. Return false otherwise.
{ return (root == nullptr); }

//in book fig 12.3 
//clones the Node and returns 
BET::BinaryNode* BET::clone(BinaryNode *t) const  //: clone all nodes in the subtree pointed to by t. Called by functions such as the assignment operator=.
{
	if( t == nullptr )
		return nullptr;
	else
		return new BinaryNode{ t->element, clone(t->left), clone(t->right)};
}

//: print to the standard output the corresponding infix expression. 
//Note that you may need to add parentheses depending on the precedence 
//of operators. You should not have unnecessary parentheses.
//--------------------------------------------------------------------
//--------------------------------------------------------------------
//		printInfixExpression (private)
//--------------------------------------------------------------------
//--------------------------------------------------------------------
void BET::printInfixExpression(BinaryNode *n) //: print to the standard output the corresponding infix expression. Note that you may need to add parentheses depending on the precedence of operators. You should not have unnecessary parentheses.
{ 
	
	//cout<<"inside Infix Expression function\n";
	if( isalnum(n->element[0]) )
		cout<< n->element <<" ";
	//for the left side
	else
	{
		if ( isalnum(n->left->element[0])) 	//if left node is operand
			printInfixExpression(n->left);
		//determine if we need left parentesis
		else if
		( 
			(!isalnum(n->left->element[0]))

			&&

			(
				(	//in the case (parent element is mult, divide, plus or minus) and (left element is a plus or minus ) 
					((n->element == "*") || (n->element== "/") || (n->element == "-") || (n->element == "+")) && 
						((n->left->element == "+") || (n->left->element == "-"))
				) 

				|| 	//or

				( 	//case (parent element is a mult or divide and left is also mult or divide) plus an minus are associative
					((n->element == "/") || (n->element == "*")) && 
						((n->left->element == "/") || (n->left->element == "*"))  
				)
			) 

		)//end else if condition requirement
	    {
	    	cout<< "( ";
	    	printInfixExpression(n->left);
	    	cout<< ") "; 
	    }

	    else
	    	printInfixExpression(n->left);
	    cout<<n->element << " ";

	    //------------------
	    //almost exactly same as left case
	    //done to the right
	    //-------------------
	    //
	    if( isalnum(n->right->element[0]))
	    	cout<< n->right->element<< " ";
	    else
		{	
			if ( isalnum(n->right->element[0])) 	//if right node is operand
				printInfixExpression(n->right);
			//determine if we need right parentesis
			else if
			( 
				(!isalnum(n->right->element[0]))

				&&

				(
					(	//in the case (parent element is mult, divide, plus or minus) and (right element is a plus or minus ) 
						((n->element == "*") || (n->element== "/") || (n->element == "-") || (n->element == "+")) && 
							((n->right->element == "+") || (n->right->element == "-"))
					) 

					|| 	//or

					( 	//case (parent element is a mult or divide and right is also mult or divide) plus an minus are associative
						((n->element == "/") || (n->element == "*")) && 
							((n->right->element == "/") || (n->right->element == "*"))  
					)
				) 

			)//end else if condition requirement
	    {
	    	cout<< "( ";
	    	printInfixExpression(n->right);
	    	cout<< ") "; 
	    }

	    else
	    	printInfixExpression(n->right);
		}
	}
}// end of printInfixExpression private method

//----------------------
//makeEmpty
//
void BET::makeEmpty(BinaryNode* &t) //: delete all nodes in the subtree pointed to by t. Called by functions such as the destructor.
{ 
	if( t != nullptr) //if it contains something, recursivly delete everything 
	{
		makeEmpty(t->right);
		makeEmpty(t->left);
		delete t;
	}
}
void BET::printPostfixExpression(BinaryNode *n) //: print to the standard output the corresponding postfix expression.
{
	if ( n->left == nullptr )
		cout<< n->element <<" ";
	else
	{
		printPostfixExpression(n->left);
		printPostfixExpression(n->right);
		cout<< n->element <<" ";
	}	
}
size_t BET::size(BinaryNode *t) //: return the number of nodes in the subtree pointed to by t.
{
	if( t->left == nullptr )
		return 1;
	else
		return 1 + size(t->left) + size(t->right); 
}
size_t BET::leaf_nodes(BinaryNode *t) //: return the number of leaf nodes in the subtree pointed to by t.
{
	if( t->left == nullptr )
		return 1;
	return leaf_nodes(t->left) + leaf_nodes(t->right);
}
