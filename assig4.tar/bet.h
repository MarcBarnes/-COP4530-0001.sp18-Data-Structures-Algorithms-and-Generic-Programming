//MARCUS BARNES
//cop4530
//BINARY EXPRESSION TREE
/*
This header file contains the interface of a tree structure designed to take in a postfix
expression and analyze it for operators and operands while using recursive algorithms and
be able to convert to infix expression with parenthesis.
FILES: 	bet.h
		bet.hpp
		proj4_driver.cpp
		makefile
		analysis.txt
*/

#ifndef BET_H
#define BET_H

#include <iostream>
#include <string>
#include <stack>
#include <vector>
using namespace std;

//begin of class BINARY EXPRESSION TREE
class BET
{
private:
	struct BinaryNode
	{
		string element; //the data in the node
		BinaryNode *left; //left child
		BinaryNode *right; //right child

	};// end of BinaryNode struture

public: 
	BET();						// default zero-parameter constructor.
	//one-parameter constructor, where parameter "postfix" is string containing a postfix expression. 
	//The tree should be built based on the postfix expression. 
	//Tokens in the postfix expression are separated by space.
	BET(const string postfix);	
	BET(const BET&); //: copy constructor.
	~BET(); //: destructor.

	bool buildFromPostfix(const string postfix); //: parameter "postfix" is string containing a postfix expression. The tree should be built based on the postfix expression. Tokens in the postfix expression are separated by space. If the tree contains nodes before the function is called, you need to first delete the existing nodes. Return true if the new tree is built successfully. Return false if an error is encountered.
	const BET & operator= (const BET &); //: assignment operator.
	void printInfixExpression(); //: call the private version of the printInfixExpression function to print out the infix expression.
	void printPostfixExpression(); //: call the private version of the printPostfixExpression function to print out the postfix expression.
	size_t size(); //: call the  private version of the size function to return the number of nodes in the tree.
	size_t leaf_nodes(); // : call the private version of the leaf_nodes function to return the number of leaf nodes in the tree.
	bool empty(); //: return true if the tree is empty. Return false otherwise.

private:
	BinaryNode *root;		//pointer to the root
	BinaryNode *nullNode;	//pointer to blank Node


	BinaryNode * clone(BinaryNode *t) const ; //: clone all nodes in the subtree pointed to by t. Called by functions such as the assignment operator=.
	void printInfixExpression(BinaryNode *n); //: print to the standard output the corresponding infix expression. Note that you may need to add parentheses depending on the precedence of operators. You should not have unnecessary parentheses.
	void makeEmpty(BinaryNode* &t); //: delete all nodes in the subtree pointed to by t. Called by functions such as the destructor.
	void printPostfixExpression(BinaryNode *n); //: print to the standard output the corresponding postfix expression.
	size_t size(BinaryNode *t); //: return the number of nodes in the subtree pointed to by t.
	size_t leaf_nodes(BinaryNode *t); //: return the number of leaf nodes in the subtree pointed to by t.

};

#include "bet.hpp"
#endif