//Marcus Barnes
//Assignment 1 
//I know this writing is very messy, sorry



#include <iostream>
#include <cstdlib>
#include <iterator>
#include <string>
#include <vector>
#include <sstream>
#include <algorithm>
#include <map>
#include <istream>
#include <locale>
#include <sstream>
#include <cctype>
#include <stdio.h>
#include <iomanip>

using namespace std;
//								FUNCTION DEC
//accesors functions
void showValues(const vector<string> & vect);				//accesor	
//mutators functions
void makeCharArray(const vector<string> & vect , vector<string> & charVector);	
void MakeNumMap(const vector<string> & v ,  map<string, int> & m);
void MakeCharMap(const vector<char> & v ,  map<string, int> & m);
void MakeWordMap(const vector<string> & v ,  map<string, int> & m);
void findTopTen( map<string , int> & m );
void findTopWords( vector<string> & topv, const vector<string> & v , const map<string, int> & m);
/////////////////////////////////////////////

//*************************************************
//		findTopWords //
//*************************************************
//vector <string> & findTopWords(vector<string> & v , map<string, int> & m)
//{

//}
//*************************************************
//*************************************************
//*************************************************

//*************************************************
//		MakeWordMap
//*************************************************
void MakeWordMap(const vector<string> & v ,  map<string, int> & m)
{
	string str;
	string temp;

	for (unsigned int i =0; i < v.size(); i++)
	{	
		str = v[i];
		for (unsigned int j = 0; j< str.size(); j++) 
		{
			str[j] = tolower(str[j]);
			if (isalpha(str[j]))
				temp = temp + str[j];
			else
			{
				if (temp != "")
				{
					m[temp] = m[temp] + 1;
					temp = "";
				}
			}
		}
		if(temp=="")
			continue;
		else				//pop it to the map, temp
		{	
			m[temp] = m[temp] + 1;
			cout<<"here"<< m[temp]<<endl;
		}
		temp = "";
	}
std::map<string , int>::iterator itr = m.begin();
//for(itr = m.begin()  ; itr !=m.end() ;  itr++)
//{
//	cout<<"word MAP: "<<itr->first<<" => "<<itr->second<<endl;
//}
}
//*************************************************
//*************************************************
//*************************************************

//*************************************************
//			MakeCharMap
//*************************************************
void MakeCharMap(const vector<char> & v  , map<string, int> & m)
{
	string temp = "";
	for (unsigned int i = 0; i < v.size();i++)
	{
		temp = v[i];
		m[temp] = m[temp] + 1;
	}

}
//*************************************************
//********************************************
//***************************************

//*************************************************
//			findTopTen																*
//*************************************************
void findTopTen( map<string , int> & m )
{
 auto max = 0;
 map<string , int> mapTen;
 vector<string> firstTen;
 vector<int> secondTen;
 string str;      //to hold the key that contains the max value
        //defining itr pointer before I check if map has 10 keys
  map<string , int>::iterator itr = m.begin();
	//unsigned int padding;

 if (m.size() < 10 )
 {
		int x = 0;
 		for (itr = m.begin(); itr !=m.end(); itr++)
			{
				if (itr->second > max)
					{
						max = itr->second;
						str = itr->first;
					}
				
		//	padding = str.size() + 5;
		cout<<"No. "<< x <<": "<< setw(20)<< left ;
	
		if (str == "\n")
			cout<<"\\n"<< setw(10) << max <<endl;
		else if (str == "\t")
			cout<<"\\t"<< setw(10) << max <<endl;
		else 		
			cout<< str << setw(10) << max <<endl;
   
			max = 0;
			x++;
			m.erase(str);
			}
	cout<<endl;
	}
	
  				

else
	{
		for (int x=0; x<10; x++)
		{
			for (itr = m.begin(); itr !=m.end(); itr++)
			{
				if (itr->second > max)
				{
					max = itr->second;
					str = itr->first;
				}
			}
	//	padding = str.size() + 5;
	cout<<"No. "<< x <<": "<< setw(20)<< left ;
	
	if (str == "\n")
		cout<<"\\n"<< setw(10) << max <<endl;
	else if (str == "\t")
		cout<<"\\t"<< setw(10) << max <<endl;
	else 		
		cout<< str << setw(10) << max <<endl;
   
			max = 0;
			m.erase(str);
		}
		cout<<endl;
	}
}
//************************************************
//*****************************************
//***********************************END

//**************************************************
// 					MAIN FUNCTION
//**************************************************
int main()
{
	map <string , int> char_Map;
	map <string , int> int_Map;
	map <string , int> word_Map;
	vector<string> tolkValues;				//to hold all of the redirected stdin
	vector<string> allCharsVector;		//Holds all individual character arrays
	vector<string> allWordsVector;		//Holds all individual words and their place 
	vector<char> charInput;																//of occurance
	vector<string> allNumbersVector;	//Holds all the set of numbers
	//int numValues;					//to hold the number of redirected stdin
	string tempString; //commented out**
	//get all the redirected stdin placed into vector
	 char ch;
	 string tolken="";
	 while (cin.get(ch))
	{
		charInput.push_back(ch);
		if(ch =='\n' || ch == ' ')
		{
			tolken = tolken + ch;
			tolkValues.push_back(tolken);
			tolken = "";
		}
		else
			tolken = tolken + ch;

	}
	//showValues (tolkValues);
	
	makeCharArray(tolkValues, allCharsVector);
	MakeNumMap(tolkValues , int_Map);
	MakeCharMap(charInput , char_Map);
	MakeWordMap(tolkValues , word_Map);
	
	cout<<"Total "<<char_Map.size()<<" different characters, 10 most used chars:\n";
	findTopTen(char_Map );
	
	cout<<"Total "<<word_Map.size()<<" different words, 10 most used words:\n";
	findTopTen(word_Map );
	
	cout<<"Total "<<int_Map.size()<<" different numbers, 10 most used numbers:\n";
	findTopTen(int_Map );

return 0;
}

//************************************************
//*****************************************
//***********************************END


/******************************************************
//			showValues
******************************************************/
//Function to show the values in a vector
void showValues(const vector<string> & vect)
{
	int size = vect.size();
	for (int count = 0; count < size; count++)		
		cout <<"Element "<< count<< ": "<< vect[count] << endl;
}
//************************************************
//*****************************************
//***********************************END

//*****************************************************
//		FUNCTION TO make INDIVIDUAL CHARACTERS array OUT OF STRINGS OF VECTOR
//
//*****************************************************/

void makeCharArray(const vector<string> & vect, vector<string> & charVector)
{
	string tempStr;
	char tempChar;
	int numOfChars = 0;
	int charTotal =0;	
	
	int size = vect.size();
	//for loop to loop through every vector of values
	for (int x = 0; x < size; x++)
	{			
		//set how many characters are in the vector
		numOfChars = vect[x].size();
		//for loop to go through character in each
		for (int y = 0; y < (numOfChars + 1); y++)
		{
		  tempChar = vect[x] [y];					//creating temp char
			//tempChar = tolower(tempChar);		//converting character to lowercase
			tempStr = tempChar;
			charVector.push_back(tempStr);	//placing in a vector
			
			//cout<< "We are at character: "<< charTotal;
			//cout<< " which is: " << charVector[charTotal]<<"\n";
			charTotal++; //iterating the counter/total of charVector arrays
		} 
	}

}
//********************************************************
//											END OF FUNCTION							 		*
//*******************************************************



//*************************************************
//		BEGIN the makeNum map
//*************************************************

//*************************************************
// 				MakeNumMap
//*************************************************
void MakeNumMap(const vector<string> & v  , map<string, int> & m)
{
	string str;
	string temp;
	for (unsigned int i =0; i < v.size(); i++)
	{	
		str = v[i];
		for (unsigned int j = 0; j< str.size(); j++)
		{
			if (isdigit(str[j]))
				temp = temp + str[j];
			else
			{
				if (temp != "")
					m[temp] = m[temp] + 1;
				temp = "";
			}
		}
	if(temp=="")
		continue;
	else				//pop it to the map, temp
		m[temp] = m[temp] + 1; 
	temp = "";
	}
/*
	std::locale loc;
	std::string str="1776ad";
		if (isdigit(str[0],loc))
	  	{
	   	 int year;
	   	 std::stringstream(str) >> year;
	   	 std::cout << "The year that followed " << year << " was " << (year+1) << ".\n";
	  	}
*/
}
//*************************************************
//*************************************************
//*************************************************
